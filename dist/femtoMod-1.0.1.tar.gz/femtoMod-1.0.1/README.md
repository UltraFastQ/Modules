# Modules
This repository is a combination of the modules created by the femtoQ laboratory. This packages are to help with various things in our lab from loading csv file in a given format to plotting figures with a specific format.
